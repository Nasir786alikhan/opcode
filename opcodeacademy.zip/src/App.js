import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Router } from 'react-router-dom';
import Footer from './component/Footer';
import NotFound from './pages/NotFound';
import Header from './component/Header';
import Index from './pages/Index';

function App() {
  return (
    <BrowserRouter>
      <Router>
        <Header />
        <Route path="/" element={<Index />} />
        <Route path="/pagenotfound/" element={<NotFound />} />
        <Footer />
      </Router>
    </BrowserRouter>
  );
}

export default App;
